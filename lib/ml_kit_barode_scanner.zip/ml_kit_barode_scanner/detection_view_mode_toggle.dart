import 'package:flutter/material.dart';
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';
import 'package:image_picker/image_picker.dart';

class DetectionViewModeToggle extends StatefulWidget {
  const DetectionViewModeToggle({super.key, required this.onImage});

  final Function(InputImage inputImage) onImage;

  @override
  State<DetectionViewModeToggle> createState() => _DetectionViewModeToggleState();
}

class _DetectionViewModeToggleState extends State<DetectionViewModeToggle> {
  ImagePicker? _imagePicker;

  @override
  void initState() {
    super.initState();
    _imagePicker = ImagePicker();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
       decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(100),
        color: Colors.black.withAlpha(100),
      ),
      padding: const EdgeInsets.all(5),
      child: IconButton(
        onPressed: () {
          _getImage(ImageSource.gallery);
        },
        iconSize: 32.0,
        icon: const Icon(
          Icons.photo_library_outlined,
          color: Colors.white,
        ),
      ),
    );
  }

  Future _getImage(ImageSource source) async {
    final pickedFile = await _imagePicker?.pickImage(source: source);
    if (pickedFile != null) {
      _processFile(pickedFile.path);
    }
  }

  Future _processFile(String path) async {
    final inputImage = InputImage.fromFilePath(path);
    widget.onImage(inputImage);
  }
}
